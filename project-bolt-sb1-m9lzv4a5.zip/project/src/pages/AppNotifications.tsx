import React from 'react';
import { useParams } from 'react-router-dom';
import { mockNotifications } from '../data';
import { NotificationCard } from '../components/NotificationCard';

export function AppNotifications() {
  const { appType } = useParams();
  
  const appName = appType === 'messaging' 
    ? 'Messaging App' 
    : appType === 'social' 
      ? 'Social Media App' 
      : 'Email App';
  
  const notifications = mockNotifications.filter(n => n.sourceApp === appName);

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-gray-800 mb-6">{appName} Notifications</h1>
      <div className="space-y-4">
        {notifications.map(notification => (
          <NotificationCard key={notification.id} notification={notification} />
        ))}
      </div>
    </div>
  );
}