import React from 'react';
import { mockNotifications } from '../data';
import { LayoutDashboard, Bell, MessageSquare, Share2, Mail, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export function Dashboard() {
  const stats = {
    total: mockNotifications.length,
    messaging: mockNotifications.filter(n => n.sourceApp === 'Messaging App').length,
    social: mockNotifications.filter(n => n.sourceApp === 'Social Media App').length,
    email: mockNotifications.filter(n => n.sourceApp === 'Email App').length,
  };

  return (
    <div className="p-6">
      <div className="flex items-center gap-3 mb-8">
        <div className="p-3 bg-blue-600 rounded-lg">
          <LayoutDashboard className="w-6 h-6 text-white" />
        </div>
        <h1 className="text-2xl font-bold text-gray-800">Dashboard</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <Bell className="w-5 h-5 text-blue-600" />
            <span className="text-sm text-gray-500">Total</span>
          </div>
          <p className="text-2xl font-bold text-gray-800">{stats.total}</p>
          <p className="text-sm text-gray-600 mt-1">Total Notifications</p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <MessageSquare className="w-5 h-5 text-green-600" />
            <span className="text-sm text-gray-500">Messaging</span>
          </div>
          <p className="text-2xl font-bold text-gray-800">{stats.messaging}</p>
          <p className="text-sm text-gray-600 mt-1">Messaging Notifications</p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <Share2 className="w-5 h-5 text-purple-600" />
            <span className="text-sm text-gray-500">Social</span>
          </div>
          <p className="text-2xl font-bold text-gray-800">{stats.social}</p>
          <p className="text-sm text-gray-600 mt-1">Social Media Notifications</p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <Mail className="w-5 h-5 text-red-600" />
            <span className="text-sm text-gray-500">Email</span>
          </div>
          <p className="text-2xl font-bold text-gray-800">{stats.email}</p>
          <p className="text-sm text-gray-600 mt-1">Email Notifications</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Link
          to="/app/messaging"
          className="group bg-white p-6 rounded-lg shadow-sm border border-gray-200 hover:border-blue-300 transition-colors"
        >
          <div className="flex items-center justify-between mb-4">
            <MessageSquare className="w-6 h-6 text-green-600" />
            <ArrowRight className="w-5 h-5 text-gray-400 group-hover:text-blue-500 transition-colors" />
          </div>
          <h3 className="text-lg font-semibold text-gray-800 mb-2">Messaging App</h3>
          <p className="text-sm text-gray-600">View all messaging notifications and updates</p>
        </Link>

        <Link
          to="/app/social"
          className="group bg-white p-6 rounded-lg shadow-sm border border-gray-200 hover:border-blue-300 transition-colors"
        >
          <div className="flex items-center justify-between mb-4">
            <Share2 className="w-6 h-6 text-purple-600" />
            <ArrowRight className="w-5 h-5 text-gray-400 group-hover:text-blue-500 transition-colors" />
          </div>
          <h3 className="text-lg font-semibold text-gray-800 mb-2">Social Media App</h3>
          <p className="text-sm text-gray-600">Check your social media activity and interactions</p>
        </Link>

        <Link
          to="/app/email"
          className="group bg-white p-6 rounded-lg shadow-sm border border-gray-200 hover:border-blue-300 transition-colors"
        >
          <div className="flex items-center justify-between mb-4">
            <Mail className="w-6 h-6 text-red-600" />
            <ArrowRight className="w-5 h-5 text-gray-400 group-hover:text-blue-500 transition-colors" />
          </div>
          <h3 className="text-lg font-semibold text-gray-800 mb-2">Email App</h3>
          <p className="text-sm text-gray-600">Access your email notifications and updates</p>
        </Link>
      </div>
    </div>
  );
}