import React, { useState } from 'react';
import { MessageSquare, Share2, Mail, Clock, MessageCircle, ThumbsUp, AlertCircle, CheckCircle } from 'lucide-react';
import { Notification, AIAnalysis } from '../types';

interface NotificationCardProps {
  notification: Notification;
}

const sourceIcons = {
  'Messaging App': MessageSquare,
  'Social Media App': Share2,
  'Email App': Mail,
};

const priorityColors = {
  high: 'bg-red-50 text-red-600',
  medium: 'bg-yellow-50 text-yellow-600',
  low: 'bg-green-50 text-green-600',
};

export function NotificationCard({ notification }: NotificationCardProps) {
  const [showSummary, setShowSummary] = useState(false);
  const [showReplyOptions, setShowReplyOptions] = useState(false);
  const [showAIAnalysis, setShowAIAnalysis] = useState(false);
  const Icon = sourceIcons[notification.sourceApp];

  const mockAIAnalysis: AIAnalysis = {
    sentiment: 'positive',
    urgency: 8,
    suggestedAction: 'Respond within 2 hours to maintain engagement',
    keyPoints: ['High priority item', 'Requires immediate attention', 'Team collaboration opportunity']
  };

  return (
    <div className={`bg-white rounded-lg shadow-sm border transition-all hover:shadow-md ${
      notification.isRead ? 'border-gray-100' : 'border-blue-100'
    }`}>
      <div className="p-4">
        <div className="flex items-start gap-4">
          <div className={`p-2 rounded-full ${
            notification.isRead ? 'bg-gray-50' : 'bg-blue-50'
          }`}>
            <Icon className={`w-5 h-5 ${
              notification.isRead ? 'text-gray-600' : 'text-blue-600'
            }`} />
          </div>
          <div className="flex-1">
            <div className="flex items-start justify-between mb-2">
              <div>
                <h3 className="font-semibold text-gray-800 mb-1">{notification.subject}</h3>
                <div className="flex items-center gap-2 text-sm text-gray-500">
                  <span className="flex items-center">
                    <Clock className="w-4 h-4 mr-1" />
                    {new Date(notification.timestamp).toLocaleTimeString()}
                  </span>
                  <span className={`px-2 py-0.5 rounded-full text-xs ${priorityColors[notification.priority]}`}>
                    {notification.priority.charAt(0).toUpperCase() + notification.priority.slice(1)}
                  </span>
                  <span className="px-2 py-0.5 bg-gray-100 rounded-full text-xs text-gray-600">
                    {notification.category}
                  </span>
                </div>
              </div>
              {!notification.isRead && (
                <span className="w-2 h-2 bg-blue-600 rounded-full"></span>
              )}
            </div>
            
            <p className="text-gray-600 mb-3">{notification.content}</p>
            
            {showSummary && (
              <div className="mb-3 p-3 bg-blue-50 rounded-lg border border-blue-100">
                <p className="text-sm text-blue-700">{notification.summary}</p>
              </div>
            )}
            
            {showAIAnalysis && (
              <div className="mb-3 p-3 bg-purple-50 rounded-lg border border-purple-100">
                <h4 className="text-sm font-semibold text-purple-700 mb-2">AI Analysis</h4>
                <div className="space-y-2">
                  <p className="text-sm text-purple-700">
                    <span className="font-medium">Sentiment:</span> {mockAIAnalysis.sentiment}
                  </p>
                  <p className="text-sm text-purple-700">
                    <span className="font-medium">Urgency Score:</span> {mockAIAnalysis.urgency}/10
                  </p>
                  <p className="text-sm text-purple-700">
                    <span className="font-medium">Suggested Action:</span> {mockAIAnalysis.suggestedAction}
                  </p>
                  <ul className="text-sm text-purple-700 pl-4">
                    {mockAIAnalysis.keyPoints.map((point, index) => (
                      <li key={index} className="list-disc">{point}</li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
            
            {showReplyOptions && (
              <div className="mb-3 flex flex-wrap gap-2">
                {notification.replyOptions.map((option, index) => (
                  <button
                    key={index}
                    className="px-3 py-1.5 text-sm bg-white border border-gray-200 hover:bg-gray-50 rounded-lg text-gray-700 transition-colors"
                  >
                    {option}
                  </button>
                ))}
              </div>
            )}
            
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setShowSummary(!showSummary)}
                className="flex items-center gap-1.5 px-3 py-1.5 text-sm bg-blue-50 hover:bg-blue-100 rounded-lg text-blue-700 transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                {showSummary ? 'Hide Summary' : 'Summarize'}
              </button>
              <button
                onClick={() => setShowReplyOptions(!showReplyOptions)}
                className="flex items-center gap-1.5 px-3 py-1.5 text-sm bg-green-50 hover:bg-green-100 rounded-lg text-green-700 transition-colors"
              >
                <ThumbsUp className="w-4 h-4" />
                {showReplyOptions ? 'Hide Replies' : 'Smart Reply'}
              </button>
              <button
                onClick={() => setShowAIAnalysis(!showAIAnalysis)}
                className="flex items-center gap-1.5 px-3 py-1.5 text-sm bg-purple-50 hover:bg-purple-100 rounded-lg text-purple-700 transition-colors"
              >
                <AlertCircle className="w-4 h-4" />
                {showAIAnalysis ? 'Hide Analysis' : 'AI Analysis'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}