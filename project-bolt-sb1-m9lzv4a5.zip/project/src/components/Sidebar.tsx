import React from 'react';
import { NavLink } from 'react-router-dom';
import { LayoutDashboard, Bell, MessageSquare, Share2, Mail } from 'lucide-react';

export function Sidebar() {
  return (
    <div className="w-64 bg-white border-r border-gray-200 min-h-screen p-4">
      <div className="flex items-center gap-2 mb-8">
        <Bell className="w-6 h-6 text-blue-600" />
        <h1 className="text-xl font-bold text-gray-800">Notification Hub</h1>
      </div>
      
      <nav className="space-y-2">
        <NavLink
          to="/"
          className={({ isActive }) =>
            `flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
              isActive
                ? 'bg-blue-50 text-blue-600'
                : 'text-gray-600 hover:bg-gray-50'
            }`
          }
        >
          <LayoutDashboard className="w-5 h-5" />
          <span>Dashboard</span>
        </NavLink>
        
        <NavLink
          to="/notifications"
          className={({ isActive }) =>
            `flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
              isActive
                ? 'bg-blue-50 text-blue-600'
                : 'text-gray-600 hover:bg-gray-50'
            }`
          }
        >
          <Bell className="w-5 h-5" />
          <span>All Notifications</span>
        </NavLink>
        
        <div className="pt-4 mt-4 border-t border-gray-200">
          <h2 className="px-4 text-sm font-semibold text-gray-500 mb-2">Apps</h2>
          <NavLink
            to="/app/messaging"
            className={({ isActive }) =>
              `flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                isActive
                  ? 'bg-blue-50 text-blue-600'
                  : 'text-gray-600 hover:bg-gray-50'
              }`
            }
          >
            <MessageSquare className="w-5 h-5" />
            <span>Messaging</span>
          </NavLink>
          
          <NavLink
            to="/app/social"
            className={({ isActive }) =>
              `flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                isActive
                  ? 'bg-blue-50 text-blue-600'
                  : 'text-gray-600 hover:bg-gray-50'
              }`
            }
          >
            <Share2 className="w-5 h-5" />
            <span>Social Media</span>
          </NavLink>
          
          <NavLink
            to="/app/email"
            className={({ isActive }) =>
              `flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                isActive
                  ? 'bg-blue-50 text-blue-600'
                  : 'text-gray-600 hover:bg-gray-50'
              }`
            }
          >
            <Mail className="w-5 h-5" />
            <span>Email</span>
          </NavLink>
        </div>
      </nav>
    </div>
  );
}