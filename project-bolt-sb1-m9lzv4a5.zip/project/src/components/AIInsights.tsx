import React from 'react';
import { Brain, Zap, TrendingUp } from 'lucide-react';

interface AIInsightsProps {
  analysis: {
    sentiment: 'positive' | 'neutral' | 'negative';
    urgency: number;
    suggestedAction: string;
    keyPoints: string[];
  };
}

export function AIInsights({ analysis }: AIInsightsProps) {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-purple-100 overflow-hidden">
      <div className="p-4 bg-purple-50 border-b border-purple-100">
        <div className="flex items-center gap-2">
          <Brain className="w-5 h-5 text-purple-600" />
          <h2 className="text-lg font-semibold text-purple-900">AI Insights</h2>
        </div>
      </div>
      
      <div className="p-4 space-y-4">
        <div className="flex items-start gap-4">
          <div className="p-2 bg-purple-50 rounded-lg">
            <Zap className="w-5 h-5 text-purple-600" />
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-900 mb-1">Priority Action</h3>
            <p className="text-sm text-gray-600">{analysis.suggestedAction}</p>
          </div>
        </div>
        
        <div className="flex items-start gap-4">
          <div className="p-2 bg-purple-50 rounded-lg">
            <TrendingUp className="w-5 h-5 text-purple-600" />
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-900 mb-1">Key Insights</h3>
            <ul className="space-y-2">
              {analysis.keyPoints.map((point, index) => (
                <li key={index} className="text-sm text-gray-600 flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-purple-400 mt-1.5" />
                  {point}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}