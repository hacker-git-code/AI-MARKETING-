export interface Notification {
  id: string;
  sourceApp: 'Messaging App' | 'Social Media App' | 'Email App';
  subject: string;
  content: string;
  timestamp: string;
  summary: string;
  replyOptions: string[];
  priority: 'high' | 'medium' | 'low';
  category: string;
}

export interface NotificationGroup {
  sourceApp: string;
  notifications: Notification[];
}