import { Notification } from './types';

export const mockNotifications: Notification[] = [
  {
    id: '1',
    sourceApp: 'Messaging App',
    subject: 'Team Meeting',
    content: 'Weekly team sync at 2 PM today',
    timestamp: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
    summary: 'Weekly team sync meeting reminder. Review last week\'s progress.',
    replyOptions: ['Will attend', 'Running late', 'Cannot attend'],
    priority: 'high',
    category: 'Meetings'
  },
  {
    id: '2',
    sourceApp: 'Social Media App',
    subject: 'New Friend Request',
    content: 'Sarah Johnson wants to connect with you',
    timestamp: new Date(Date.now() - 1000 * 60 * 60).toISOString(),
    summary: 'New connection request from Sarah Johnson. Profile shows mutual connections.',
    replyOptions: ['Accept', 'Decline', 'View Profile'],
    priority: 'medium',
    category: 'Connections'
  },
  {
    id: '3',
    sourceApp: 'Email App',
    subject: 'Project Deadline Update',
    content: 'The deadline for the Q1 report has been extended',
    timestamp: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
    summary: 'Project deadline extension notification. New submission date available.',
    replyOptions: ['Acknowledge', 'Request Details', 'Schedule Review'],
    priority: 'high',
    category: 'Projects'
  },
  {
    id: '4',
    sourceApp: 'Messaging App',
    subject: 'New Group Chat',
    content: 'You\'ve been added to "Product Team 2024"',
    timestamp: new Date(Date.now() - 1000 * 60 * 180).toISOString(),
    summary: 'Added to new product team group chat. 12 members present.',
    replyOptions: ['Say Hello', 'Mute Chat', 'Leave Group'],
    priority: 'medium',
    category: 'Groups'
  },
  {
    id: '5',
    sourceApp: 'Social Media App',
    subject: 'Post Engagement',
    content: 'Your recent post has 50+ likes',
    timestamp: new Date(Date.now() - 1000 * 60 * 240).toISOString(),
    summary: 'High engagement on your recent post. Trending in your network.',
    replyOptions: ['View Analytics', 'Boost Post', 'Thank Followers'],
    priority: 'low',
    category: 'Engagement'
  }
];